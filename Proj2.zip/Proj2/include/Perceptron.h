#ifndef PERCEPTRON_H
#define PERCEPTRON_H

 struct Perceptron{};

    float weights[] = new float[3];
    float lr= 0.1;

Perceptron() {     //Intializes the weights
    for (int i = 0; i< sizeof(weights)/sizeof(weights[0]); i++){
        weights[i]= rand(0,.5);
        }
}


int check (float n){
    if (n>.5){
    return 1;
    }
    else{
        return 0;
    }
}
int guess(float[] inputs){  //multiplies inputs by weights
flaot sum=0;
for (int i = 0; i< sizeof(weights)/sizeof(weights[0]); i++){
    sum += inputs[i] * weights[i];
}
 return check(sum);
}
void train(float[] inputs, int target){
    int guess= guess(inputs);
    int error = target - guess;
        for(int i = 0; i< sizeof(weights)/sizeof(weights[0]); i++)  //tune the weights
        weights[i] += error * inputs[i] * lr;
}

float guessY(float x){
float w0 = weights[0];
float w1 = weights[1];
float w2 = weights[2];
return -(w2/w1) - (w0/w1) * x;
}

 }






#endif // PERCEPTRON_H

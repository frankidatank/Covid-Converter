//#include "Perceptron.h"
//
//Perceptron::Perceptron()
//{
//    //ctor
//}
//
//Perceptron::~Perceptron()
//{
//    //dtor
//}

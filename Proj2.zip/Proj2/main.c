//Frank Murillo 1031158
//fm1031158@swccd.edu


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
double threshold (double n);
double dotprod(double inputs[],double weights[]);
void Printnewweights(double weights[]);

int main()
{
    double x[4][3]= {{1,0,0},
        {1,0,1},
        {1,1,0},
        {1,1,1}
    };
    double y[] = {1,1,1,0};

    double weights[3] = {0,0,0};

    //Intiallizes:
    double prod;
    double lr= 0.1;
    double sum;
    int col;
    int row;
    double error;
    int i =1;
//Start of the do/while loop
    do
    {
        printf("\nIteration number: %d\n", i);

//nested for loop that iterates each col, followed by row:
        for ( row=0; row<4; row++)
        {

            prod=0;
//Dot product
            for (col=0; col<3; col++)
            {
                prod += (x[row][col]) * (weights[col]);
            }
//Calculates the sum as the threshold of Prod:
            sum = threshold(prod);

//Tunes the weights if sum[row] is not equal so y[row]
            if (sum != y[row])
            {
//calculates the error
                error = y[row] - sum ;


                for(int j = 0; j< 3; j++)
                {


                    weights[j] = weights[j]+ ((error) * x[row][j] * lr);    //Equation that tunes the weights

                }


            }
            Printnewweights(weights);
        }
    }
    while (i++<8);  //counts 8 iterations


    return 0;
}








//Checks the dotproduct sum and compares to threshold returns 1 or 0
double threshold (double n)
{
    if (n>.5)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
//function that prints the adjusted weights
void Printnewweights(double weights[])
{
    printf("\nAdjusted weights: ");
    for (int i=0; i<3; i++)
    {
        printf("%f, ", weights[i]);
    }
}









